package com.gentlehealthcare.mobilecare.net;


public interface IRequest{
	abstract void doRequest();
}
