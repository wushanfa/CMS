package com.gentlehealthcare.mobilecare.net.bean;

/**
 * Created by ouyang on 15/6/3.
 */
public class RecordSecondPageSignInfo {
private String val;
    private String recordTime;
    private String type;

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }

    public String getRecordTime() {
        return recordTime;
    }

    public void setRecordTime(String recordTime) {
        this.recordTime = recordTime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
