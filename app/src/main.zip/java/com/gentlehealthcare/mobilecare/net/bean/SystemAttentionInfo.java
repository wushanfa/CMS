package com.gentlehealthcare.mobilecare.net.bean;
/**
 * 
 * @ClassName: SystemAttentionInfo 
 * @Description: 注意事项
 * @author ouyang
 * @date 2015年3月12日 下午3:29:18 
 *
 */
public class SystemAttentionInfo {
	private String noticeContent;
	private String noticeId;
	private String appCode;
	public String getNoticeContent() {
		return noticeContent;
	}
	public void setNoticeContent(String noticeContent) {
		this.noticeContent = noticeContent;
	}
	public String getNoticeId() {
		return noticeId;
	}
	public void setNoticeId(String noticeId) {
		this.noticeId = noticeId;
	}
	public String getAppCode() {
		return appCode;
	}
	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}
	
	
}
