package com.gentlehealthcare.mobilecare.swipe.interfaces;

public interface SwipeAdapterInterface {
    public int getSwipeLayoutResourceId(int position);
}
