package com.gentlehealthcare.mobilecare.bean.sys;

/**
 * Created by Zyy on 2016/5/30.
 * 类说明：
 */
public class OrdersClassDict {

    public String getNameCode() {
        return nameCode;
    }

    public void setNameCode(String nameCode) {
        this.nameCode = nameCode;
    }

    /**
     * itemName : 注射
     * itemCode : NURSING_TYPE_1
     */

    private String nameCode;

}
