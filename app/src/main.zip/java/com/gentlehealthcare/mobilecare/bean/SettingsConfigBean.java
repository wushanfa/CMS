package com.gentlehealthcare.mobilecare.bean;

/**
 * Created by ouyang on 15/7/16.
 */
public class SettingsConfigBean {
    /**
     * 胰岛素巡视间隔 半个小时
     */
    public static final long TEN_MIN_TIME=10*60*1000;
    /**
     * 第一次巡视提醒间隔
     */
    public static final long FIVE_MIN_TIEM=5*60*1000;

    public static final long ONE_HOUR_TIME=60*60*1000;

    public static final long ThIRTY_MIN_TIME=30*60*1000;

}
